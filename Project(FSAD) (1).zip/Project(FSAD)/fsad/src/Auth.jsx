import React, { useState } from "react";
import "./Auth.css";

export default function Auth({ onLoginSuccess }) {
  const [isRegistering, setIsRegistering] = useState(false);
  const [user, setUser] = useState({
    username: "",
    id: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: ""
  });

  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    if (isRegistering) {
      if (user.password !== user.confirmPassword) {
        alert("Passwords do not match!");
        return;
      }

      const userData = {
        id: user.id,
        username: user.username,
        email: user.email,
        phone: user.phone,
        password: user.password
      };

      localStorage.setItem("user", JSON.stringify(userData));
      alert("Registered successfully! You can now log in.");
      setIsRegistering(false);
      setUser({
        id: "",
        username: "",
        email: "",
        phone: "",
        password: "",
        confirmPassword: ""
      });
    } else {
      const stored = JSON.parse(localStorage.getItem("user"));
      if (
        stored &&
        stored.username === user.username &&
        stored.password === user.password
      ) {
        onLoginSuccess();
      } else {
        alert("Invalid login credentials.");
      }
    }
  };

  return (
    <div className="auth-box">
      <h2>{isRegistering ? "Register" : "Login"}</h2>

      {isRegistering && (
        <>
          <input
            type="text"
            name="id"
            placeholder="ID"
            value={user.id}
            onChange={handleChange}
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={user.email}
            onChange={handleChange}
          />
          <input
            type="text"
            name="phone"
            placeholder="Phone Number"
            value={user.phone}
            onChange={handleChange}
          />
        </>
      )}

      <input
        type="text"
        name="username"
        placeholder="Username"
        value={user.username}
        onChange={handleChange}
      />
      <input
        type="password"
        name="password"
        placeholder="Password"
        value={user.password}
        onChange={handleChange}
      />
      {isRegistering && (
        <input
          type="password"
          name="confirmPassword"
          placeholder="Confirm Password"
          value={user.confirmPassword}
          onChange={handleChange}
        />
      )}
      <button onClick={handleSubmit}>
        {isRegistering ? "Register" : "Login"}
      </button>
      <p onClick={() => setIsRegistering(!isRegistering)}>
        {isRegistering ? "Have an account? Login" : "Don't have an account? Register"}
      </p>
    </div>
  );
}
