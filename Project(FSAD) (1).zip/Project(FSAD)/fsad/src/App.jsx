import React, { useState } from "react";
import "./App.css";
import Auth from "./Auth";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [tasks, setTasks] = useState([]);
  const [filter, setFilter] = useState("all");
  const [taskInput, setTaskInput] = useState({
    name: "",
    due: "",
    project: "",
    assignedTo: ""
  });

  const addTask = () => {
    if (taskInput.name.trim() === "") return;
    setTasks([
      ...tasks,
      { ...taskInput, id: Date.now(), completed: false }
    ]);
    setTaskInput({ name: "", due: "", project: "", assignedTo: "" });
  };

  const toggleComplete = (id) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const filteredTasks = tasks.filter(t => {
    if (filter === "due") return !t.completed;
    if (filter === "completed") return t.completed;
    return true;
  });

  if (!isAuthenticated) {
    return <Auth onLoginSuccess={() => setIsAuthenticated(true)} />;
  }

  return (
    <div className="app">
      <h1>📝 <span className="title">Task Management System</span></h1>

      <div className="tabs">
        <button className={filter === "due" ? "active" : ""} onClick={() => setFilter("due")}>⚫ Due Tasks</button>
        <button className={filter === "completed" ? "active" : ""} onClick={() => setFilter("completed")}>✔ Completed</button>
        <button className={filter === "all" ? "active" : ""} onClick={() => setFilter("all")}>📋 All Tasks</button>
      </div>

      <div className="input-row">
        <input type="text" placeholder="Task" value={taskInput.name}
          onChange={(e) => setTaskInput({ ...taskInput, name: e.target.value })} />
        <input type="datetime-local" value={taskInput.due}
          onChange={(e) => setTaskInput({ ...taskInput, due: e.target.value })} />
        <input type="text" placeholder="Project" value={taskInput.project}
          onChange={(e) => setTaskInput({ ...taskInput, project: e.target.value })} />
        <input type="text" placeholder="Assigned to" value={taskInput.assignedTo}
          onChange={(e) => setTaskInput({ ...taskInput, assignedTo: e.target.value })} />
        <button className="add-btn" onClick={addTask}>+ Add Task</button>
      </div>

      <div className="task-list">
        {filteredTasks.length === 0 ? (
          <p>No tasks found.</p>
        ) : (
          filteredTasks.map(task => (
            <div key={task.id} className={`task ${task.completed ? "done" : ""}`}>
              <strong>{task.name}</strong> – {task.project} – {task.assignedTo}
              <span>{task.due ? new Date(task.due).toLocaleString() : "No due date"}</span>
              <button onClick={() => toggleComplete(task.id)}>
                {task.completed ? "Undo" : "Mark Done"}
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
