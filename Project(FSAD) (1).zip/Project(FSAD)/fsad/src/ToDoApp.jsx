import { useEffect, useState } from "react";
import "./ToDo.css";

function TodoApp() {
  const [tasks, setTasks] = useState([]);
  const [input, setInput] = useState("");
  const [date, setDate] = useState("");
  const [priority, setPriority] = useState("high");

  useEffect(() => {
    fetch("http://localhost:5173/tasks")
      .then(res => res.json())
      .then(setTasks);
  }, []);

  const addTask = async () => {
    if (!input.trim() || !date) return;

    const newTask = {
      text: input,
      date,
      priority,
      completed: false,
      startTime: new Date().toLocaleTimeString(),
      subtasks: [
        { text: "Subtask 1", completed: false },
        { text: "Subtask 2", completed: false }
      ]
    };

    const res = await fetch("http://localhost:5173/tasks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newTask)
    });

    const savedTask = await res.json();
    setTasks([...tasks, savedTask]);
    setInput("");
    setDate("");
    setPriority("high");
  };

  const completeSubtask = async (taskIndex, subIndex) => {
    const updatedTasks = [...tasks];
    const task = updatedTasks[taskIndex];
    const subtask = task.subtasks[subIndex];

    subtask.completed = !subtask.completed;
    const allDone = task.subtasks.every(st => st.completed);

    task.completed = allDone;
    task.endTime = allDone ? new Date().toLocaleTimeString() : null;

    await fetch(`http://localhost:5173/tasks/${task.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(task)
    });

    setTasks(updatedTasks);
  };

  const removeTask = async (id) => {
    await fetch(`http://localhost:5173/tasks/${id}`, { method: "DELETE" });
    setTasks(tasks.filter(t => t.id !== id));
  };

  const renderTasks = (priorityLevel) =>
    tasks
      .filter(t => t.priority === priorityLevel)
      .map((task, index) => (
        <li key={task.id} className={task.completed ? "completed task-item" : "task-item"}>
          <div className="task-header">
            <span><strong>{task.text}</strong> ({task.date})</span>
            <span className="time">Start: {task.startTime}</span>
            {task.endTime && <span className="time">End: {task.endTime}</span>}
            <button className="remove" onClick={() => removeTask(task.id)}>❌</button>
          </div>
          <ul className="subtasks">
            {task.subtasks.map((subtask, i) => (
              <li key={i} className={subtask.completed ? "completed" : ""}>
                <span>{subtask.text}</span>
                <button onClick={() => completeSubtask(index, i)}>
                  {subtask.completed ? "Undo" : "Complete"}
                </button>
              </li>
            ))}
          </ul>
        </li>
      ));

  return (
    <div className="container">
      <h1>To-Do List</h1>
      <div className="input-section">
        <input type="text" placeholder="Task" value={input} onChange={e => setInput(e.target.value)} />
        <input type="date" value={date} onChange={e => setDate(e.target.value)} />
        <select value={priority} onChange={e => setPriority(e.target.value)}>
          <option value="high">High</option>
          <option value="low">Low</option>
        </select>
        <button onClick={addTask}>Add</button>
      </div>

      <div className="task-lists">
        <div className="priority-section high">
          <h2>High Priority</h2>
          <ul>{renderTasks("high")}</ul>
        </div>
        <div className="priority-section low">
          <h2>Low Priority</h2>
          <ul>{renderTasks("low")}</ul>
        </div>
      </div>
    </div>
  );
}

export default TodoApp;
